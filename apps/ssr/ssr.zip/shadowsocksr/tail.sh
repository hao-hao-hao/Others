#!/bin/bash
cd `dirname $0`
tail -f ssserver.log
